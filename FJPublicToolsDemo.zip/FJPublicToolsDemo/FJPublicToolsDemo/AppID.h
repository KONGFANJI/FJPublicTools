//
//  AppID.h
//  FJPublicToolsDemo
//
//  Created by XY on 2017/3/17.
//  Copyright © 2017年 KFJ. All rights reserved.
//

#ifndef AppID_h
#define AppID_h

//artistID
#define MYARTISTID              @"1178540071"

//APPID
#define MYAPPID                 @"1189702803"

#define KAppStoreUrl            @"https://itunes.apple.com/app/id1189702803?mt=8"



#endif /* AppID_h */
