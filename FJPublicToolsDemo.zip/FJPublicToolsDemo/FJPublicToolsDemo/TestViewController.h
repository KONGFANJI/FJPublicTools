//
//  TestViewController.h
//  FJPublicToolsDemo
//
//  Created by XY on 2017/3/20.
//  Copyright © 2017年 KFJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController
@property (nonatomic,strong) NSDictionary *FJRouterParameter;//必须是这个
@end
